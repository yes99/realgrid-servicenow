import '../src/x-902337-home-real3';
import '@servicenow/now-button';

const el = document.createElement('DIV');
document.body.appendChild(el);

el.innerHTML = `		
<x-902337-home-real3></x-902337-home-real3>
`;
